function ex1()

seq = URNG2(3000,10000);
hist(seq);

end