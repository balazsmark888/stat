function ex2()

    seq = URealRNG(3000,2,50,60,10000);
    hist(seq);

end