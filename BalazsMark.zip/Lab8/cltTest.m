[xx,z] = TestingCLT('poisson',3,1000,1000);
hist(xx);
figure;
hist(z);