Conf_int_Binomialis(5,5000);
Conf_int_Pareto(5,5000);