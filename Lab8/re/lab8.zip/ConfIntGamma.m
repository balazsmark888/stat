function [bMin,bMax] = ConfIntGamma(alpha,n)

    b = 2;
    a = 4;
    X = gamrnd(a,b,1,n);
    x = norminv(1-alpha/2,0,1);
    s = mean(X);
    
    bMin = s / (4 + 2 * x / sqrt(n));
    bMax = s / (4 - 2 * x / sqrt(n));

end