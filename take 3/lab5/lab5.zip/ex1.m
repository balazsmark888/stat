function ex1()

    n = 10000;
    [X,m,c] = Kozrefog(n);
    hist(X);
    disp(m);
    disp(c);
    
end