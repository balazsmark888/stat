function ex4()

end